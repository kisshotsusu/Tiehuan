﻿#pragma once
#include <functional>
#include <string>

class webview_interface
{
public:
    webview_interface(const wchar_t* uniqueID)
        : m_bIs3DUI(false)
        , b_activeMouse(false)
        , m_ActiveDebugTool(false)
        , m_uniqueID(uniqueID)
    {
    }

    //加载网页 
    virtual void SetIs3DUI(bool bIs3DUI) { m_bIs3DUI = bIs3DUI; }
    bool GetIs3DUI()const {return  m_bIs3DUI; }
    //加载网页 
    virtual void LoadURL(const wchar_t* url) = 0;
    //前进
    virtual void GoForward() const = 0;
    //后退
    virtual void GoBack() const = 0;
    //重新加载
    virtual void ReLoad() const = 0;
    //停止加载
    virtual void Stop() const = 0;
    //设置webview大小
    virtual void SetBounds(RECT rect) = 0;
    //设置webview大小
    virtual void SetBounds(POINT offset, POINT size) = 0;
    //获取webview大小
    virtual RECT GetBounds() const = 0;
    //设置可见性
    virtual void SetVisible(bool is_visible) = 0;
    //获取可见性
    virtual bool GetVisible() const = 0;
    //禁用鼠标
    virtual void DisableMouse() { b_activeMouse = false; }
    //启用鼠标
    virtual void EnableMouse() { b_activeMouse = true; }
    //获取鼠标是都激活
    virtual bool IsActiveMouse() const { return b_activeMouse; }
    // 获取网页唯一标识
    std::wstring get_uniqueID() const { return m_uniqueID; }
    virtual void set_active_debug_tool(bool bIsEnableActiveTool) { m_ActiveDebugTool = bIsEnableActiveTool; }
    //@return：是否激活调试工具
    bool is_active_debug_tool() const { return m_ActiveDebugTool; }
    //给前端发送json类型的消息
    virtual void PostWebMessageAsJson(const wchar_t* Json) const = 0;
    //给前端发送string类型的消息
    virtual void PostWebMessageAsString(const wchar_t* InString) const = 0;
    virtual void Tick(float DeltaTime)=0;
    //执行前端脚本
    virtual void execute_script(const wchar_t* script) = 0;
    //关闭网页
    virtual void Clear() =0;
    //获取句柄
    virtual HWND GetMainWindowHandle() = 0;

    virtual ~webview_interface()
    {
    }

    void SetNewWindowRequestedEvent(std::function<void(const wchar_t*)> Func)
    {
        NewWindowRequestedEvent = Func;
    }

    void SetNavigationCompletedEvent(std::function<void(bool)> Func)
    {
        NavigationCompletedEvent = Func;
    }

    void SetNavigationStartingEvent(std::function<void(const wchar_t*)> Func)
    {
        NavigationStartingEvent = Func;
    }
    void SetCursorChangedEvent(std::function<void(HCURSOR)> Func)
    {
        CursorChangedEvent = Func;
    }
protected:
    bool m_bIs3DUI;
    bool b_activeMouse;
    bool m_ActiveDebugTool;
    std::wstring m_uniqueID;
    std::function<void(const wchar_t* URL)> NewWindowRequestedEvent;
    std::function<void(bool)> NavigationCompletedEvent;
    std::function<void(const wchar_t* URL)> NavigationStartingEvent;
    std::function<void(HCURSOR)> CursorChangedEvent;
};
