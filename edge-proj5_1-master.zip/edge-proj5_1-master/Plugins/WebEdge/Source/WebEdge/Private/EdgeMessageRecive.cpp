#include "EdgeMessageRecive.h"


void FEdgeMessageRecive::NoitfyReciveMessage(const wchar_t* data, size_t size)
{
	FString MessageString(data);
	GEngine->AddOnScreenDebugMessage(-1,2.f,FColor::Cyan,MessageString);
}
