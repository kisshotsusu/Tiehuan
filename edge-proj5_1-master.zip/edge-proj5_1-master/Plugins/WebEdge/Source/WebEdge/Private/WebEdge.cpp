#include "WebEdge.h"

#include "EdgeMgr.h"
#include "Misc/Paths.h"
#define LOCTEXT_NAMESPACE "FWebEdgeModule"
void FWebEdgeModule::StartupModule()
{
	Handle=nullptr;
	FString DllPath=FPaths::Combine(FPaths::ProjectDir(),TEXT("Binaries/Win64/WebView2Loader.dll"));
	DllPath =FPaths::ConvertRelativePathToFull(DllPath);
	FPlatformProcess::PushDllDirectory(*DllPath);
	Handle=FPlatformProcess::GetDllHandle(*DllPath);
	FPlatformProcess::PopDllDirectory(*DllPath);
}


void FWebEdgeModule::ShutdownModule()
{
	if(Handle)
	{
		FPlatformProcess::FreeDllHandle(Handle);
	}
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FWebEdgeModule, WebEdge)