﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/Widget.h"
#include "WebViewWidget.generated.h"

/* -------------------------------------------------------------------------------------------
 * Todo:友情提示，此类是给UMG使用的，只能创建在主窗口中，如果要创建在弹窗中（新的SWindow类）请使用SWebView *
 *--------------------------------------------------------------------------------------------*/
class SWebView;
UCLASS()
class WEBEDGE_API UWebViewWidget : public UWidget
{
	GENERATED_UCLASS_BODY()
	
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnBeforePopup, FString, NewURL);
	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnLoadStarting, FString, CurURL);
	DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnLoadComplete);
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, FieldNotify, Category="WebView")
	bool bIs3DWebUI;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, FieldNotify, Category="WebView")
	bool bIsActiveDebugTool;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, FieldNotify, Category="WebView")
	bool bIsActiveMouse;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="WebView")
	FString URL;
	UPROPERTY(BlueprintAssignable, Category = "WebView|Event")
	FOnBeforePopup OnBeforePopupEvent;
	UPROPERTY(BlueprintAssignable, Category = "WebView|Event")
    FOnLoadComplete OnLoadSuccess;
	UPROPERTY(BlueprintAssignable, Category = "WebView|Event")
    FOnLoadComplete OnLoadFailed;
	UPROPERTY(BlueprintAssignable, Category = "WebView|Event")
	FOnLoadStarting OnLoadStarting;
	UFUNCTION(BlueprintCallable, Category="WebView")
	void SetIsActiveDebugTool(bool bIsDebugTool);
	UFUNCTION(BlueprintPure, Category="WebView")
	bool GetbIsActiveDebugTool()const;
	UFUNCTION(BlueprintCallable, Category="WebView")
	void SetIsActiveMouse(bool bIsActiveMouseIn);
	UFUNCTION(BlueprintPure, Category="WebView")
	bool GetIsActiveMouse()const;
	UFUNCTION(BlueprintCallable, Category="WebView")
	void LoadURL(const FString& InURL);
	UFUNCTION(BlueprintCallable, Category="WebView")
	void GoBack();
	UFUNCTION(BlueprintCallable, Category="WebView")
	void GoForward();
	//重新加载
	UFUNCTION(BlueprintCallable, Category="WebView")
	void ReLoad() const;
	//停止加载
	UFUNCTION(BlueprintCallable, Category="WebView")
	void Stop() const;
	//给前端发送json类型的消息
	UFUNCTION(BlueprintCallable, Category="WebView")
	void PostWebMessageAsJson(const FString& Json) const;
	//给前端发送string类型的消息
	UFUNCTION(BlueprintCallable, Category="WebView")
	void PostWebMessageAsString(const FString& InString) const;
	//给前端插入脚本，并执行
	UFUNCTION(BlueprintCallable, Category="WebView")
	void ExecuteScript(const FString& script) const;

	
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	// 重写此函数以构造你的Slate界面
	virtual TSharedRef<SWidget> RebuildWidget() override;

	virtual void SynchronizeProperties() override;
#if WITH_EDITOR
	virtual const FText GetPaletteCategory()override;
#endif
protected:
	UFUNCTION()
	void OnBeforePopupCallback(const FString& NewURL);
	UFUNCTION()
	void OnLoadCompleteCallback(bool bIsSuccess);
	UFUNCTION()
	void OnLoadStartingCallback(const FString& CurURL);
private:
	TSharedPtr<SWebView> MyWebView;
	
};
