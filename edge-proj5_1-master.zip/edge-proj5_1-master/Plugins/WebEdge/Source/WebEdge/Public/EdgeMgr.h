#pragma once
#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Windows/WindowsApplication.h"
#include "EdgeMgr.generated.h"

class SWebView;
class FEdgeMessageRecive;

UCLASS()
class WEBEDGE_API UEdgeMgr:public UWorldSubsystem
{
	GENERATED_BODY()
public:
	static UEdgeMgr* Instance(UObject* WorldContext=nullptr);
	virtual void OnWorldBeginPlay(UWorld& InWorld) override;
	virtual void Deinitialize() override;

	void FocusUE();
private:
	static UEdgeMgr* g_Instance;
	FEdgeMessageRecive* EdgeMessageRecive=nullptr;

	TSharedPtr<class SEditableText> Z_TextPtr;
};


