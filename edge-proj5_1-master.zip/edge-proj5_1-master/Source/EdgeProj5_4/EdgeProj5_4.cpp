// Copyright Epic Games, Inc. All Rights Reserved.

#include "EdgeProj5_4.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, EdgeProj5_4, "EdgeProj5_4" );
