// Copyright Epic Games, Inc. All Rights Reserved.


#include "EdgeProj5_4GameModeBase.h"

